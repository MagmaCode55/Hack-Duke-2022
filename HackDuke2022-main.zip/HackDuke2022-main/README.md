# HackDuke2022
Submission for HackDuke2022 by: Robert Battle, Vishag Karthikeyan, Raunak Puranik, Mat Rizvanolli

Devpost link:
https://devpost.com/software/eduvid-nz0qyo


How to run:
- cd into eduvid
- In your terminal, run:
- pip3 install -r requirements.txt
- Once these are done downloading:
- python manage.py runserver

From there you can make user accounts, teacher accounts can post videos
