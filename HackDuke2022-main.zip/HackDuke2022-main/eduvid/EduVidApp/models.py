from email.policy import default
from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.


class User(AbstractUser):
    firstName = models.TextField(max_length=50, null=True)
    lastName = models.TextField(max_length=50, null=True)

class Student(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="studentUser")
    

class Teacher(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="teacherUser")

class Post(models.Model):
    poster = models.ForeignKey(Teacher, on_delete = models.CASCADE, related_name="poster")
    videoID = models.TextField(max_length=11)
    title = models.TextField(max_length=100)
    subject = models.IntegerField(null=True)



# Represents a reply to a comment (and subsequent replies) on a post
class PostCommentReply(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="postCommentReplyUser", default=None)
    text = models.TextField(max_length=300, default=None)
    def string(self):
        return {
            "user": self.user,
            "text": self.text,
            "id": self.id
        }

# Represents a comment on a post, with a timestamp
class PostComment(models.Model):
    video = models.ForeignKey(Post, on_delete=models.CASCADE, related_name="postComment", default=None)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="postCommentUser", default=None)
    timeStamp = models.FloatField(default=None)
    displayStamp = models.TextField(default=None, max_length=16)
    text = models.TextField(max_length=300, default=None)
    replies = models.ManyToManyField(PostCommentReply, related_name="replies", blank=True, default=None)

    def string(self):
        replyStrings = []
        for reply in self.replies.all():
            replyStrings.append(reply)
        return {
            "video": self.video,
            "user": self.user,
            "timeStamp": self.timeStamp,
            "displayStamp": self.displayStamp,
            "text": self.text,
            "replies": replyStrings,
            "id": self.id
        }