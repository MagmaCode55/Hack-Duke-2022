document.addEventListener("DOMContentLoaded", function(){
    document.getElementById("newCommentForm").addEventListener("click", function(event){
        event.preventDefault();
    });
    document.querySelectorAll(".newCommentReplyForm").forEach(btn=> btn.addEventListener("click", function(event) {
        event.preventDefault();
    }));
    document.getElementById("newCommentSubmit").addEventListener("click", function(event){
        console.log("tst");
        if (document.getElementById("newCommentText").value.length > 0 && document.getElementById("timeStampDisplay").value.length > 0) {
            fetch("/comment", {
                method: "POST",
                body: JSON.stringify({
                    timeStamp: document.getElementById("rawCommentTimeStamp").value,
                    displayStamp: document.getElementById("timeStampDisplay").value,
                    text: document.getElementById("newCommentText").value,
                    videoID: document.getElementById("videoID").innerHTML
                })
            })
            .then(response => response.json())
            .then(result =>  {
                console.log(result);
                window.location.reload();
            });
        }
    });
    document.querySelectorAll(".commentReplyButton").forEach(btn => btn.addEventListener('click', function() {
        console.log("reply")
        document.getElementById(`reply${btn.value}`).hidden = !document.getElementById(`reply${btn.value}`).hidden;
    }));
    document.querySelectorAll(".newCommentReplySubmit").forEach(btn => btn.addEventListener("click", function() {
        console.log("replyyyy")
        console.log(document.getElementById(`replyText${btn.value}`).value);
        console.log(btn.value);
        if (document.getElementById(`replyText${btn.value}`).value.length > 0) {
            fetch("/reply", {
                method: "POST",
                body: JSON.stringify({
                    text: document.getElementById(`replyText${btn.value}`).value,
                    videoID: document.getElementById("videoID").innerHTML,
                    commentID: btn.value
                })
            })
            .then(response => response.json())
            .then(result =>  {
                console.log(result);
                window.location.reload();
            });
        }
    }));

    document.querySelectorAll(".commentRepliesButton").forEach(btn => btn.addEventListener('click', function() {
        document.getElementById(`replies${btn.value}`).hidden = !document.getElementById(`replies${btn.value}`).hidden;
    }));
});