from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.shortcuts import render, redirect
from django.urls import reverse
from .models import User, Student, Teacher, Post, PostComment, PostCommentReply
from django.db import IntegrityError
from django.contrib.auth import authenticate, login, logout
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.decorators import login_required
from pytube import extract, YouTube
from django.views.decorators.csrf import csrf_exempt
import json
import random

SUBJECTSDICT = {
    "Math": 0,
    "English": 1,
    "Science": 2,
    "Social Studies": 3,
    "Arts": 4,
    "Other": 5
}
SUBJECTSLIST = ["Math", "English", "Science", "Social Studies", "Arts", "Other"]

def index(request):
    if request.user.is_authenticated:
        return render(request, "eduvid/index.html", {
            "posts": random.sample(list(Post.objects.all()), min(len(Post.objects.all()), 10)),
            "student": Student.objects.filter(user=request.user).exists()
        })
    else:
        return HttpResponseRedirect(reverse("login"))

def login_user(request):
    # If POST request
    if request.method == "POST":
        # Grab user login info from form
        username = request.POST["username"]
        password = request.POST["password"]
        # Attempt authentication
        user = authenticate(request, username=username, password=password)

        # If authenticated
        if user != None:
            # login, redirect to home
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        # If not authenticated
        else:
            # Redirect back to login back with error msg
            return render(request, "eduvid/login.html", {
                "servermsg": "Error: Invalid login."
            })
    # GET request, return login page
    return render(request, "eduvid/login.html")

def register_user(request):
    # If POST request
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        firstName = request.POST["firstName"]
        lastName = request.POST["lastName"]
        type = request.POST["userType"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "eduvid/register.html", {
                "servermsg": "Error: Passwords must match."
            })

        try:
            user = User.objects.create_user(username=username, password=password, firstName=firstName, lastName=lastName)
            if type == "student":
                userType = Student.objects.create(user=user)
            elif type == "teacher":
                userType = Teacher.objects.create(user=user)
            else:
                return render(request, "eduvid/register.html", {
                    "servermsg": "Error: Invalid user type."
                })
            user.save()
            userType.save()
            
        except IntegrityError:
            return render(request, "eduvid/register.html", {
                "servermsg": "Error: Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    return render(request, "eduvid/register.html")

@login_required
def logout_user(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))

@login_required 
def post(request):
    if request.method == "POST":
        try:
            teacher = Teacher.objects.get(user=request.user)
        except ObjectDoesNotExist:
            return HttpResponseRedirect(reverse("index"))
        title = request.POST["title"]
        subject = SUBJECTSDICT[request.POST["subject"]]
        videoID = extract.video_id(request.POST["url"])
        post = Post.objects.create(poster=teacher, videoID=videoID, title=title, subject=subject)
        post.save()
        return redirect("video", id=post.id)


    try:
        student = Student.objects.filter(user=request.user).exists()
        return render(request, "eduvid/post.html", {
            "student": student
        })
    except ObjectDoesNotExist:
        return HttpResponseRedirect(reverse("index"))

@login_required
def video(request, id):
    student = Student.objects.filter(user=request.user).exists()
    try:
        
        post = Post.objects.get(id=id)
        string = "https://youtube.com/watch?v="+post.videoID
        ytvideo = YouTube(string)
        return render(request,"eduvid/video.html", {
            "videoID": post.videoID,
            "title": post.title,
            "student": student,
            "subject": SUBJECTSLIST[post.subject],
            "description": ytvideo.description,
            "views": ytvideo.views,
            "date": ytvideo.publish_date,
            "comments": [x.string() for x in PostComment.objects.filter(video=post).order_by('timeStamp', '-id')],
            "id": post.id,
            "author": post.poster.user.firstName + " " + post.poster.user.lastName
        })
    except ObjectDoesNotExist:
        return HttpResponseRedirect(reverse("index"))

# API view
@csrf_exempt
@login_required
def comment(request):
    if request.method != "POST":
        return JsonResponse({"error": "POST method required."}, status=400)
    data = json.loads(request.body)
    timestamp = data.get("timeStamp")
    displaystamp = data.get("displayStamp")
    text = data.get("text")
    if text == "" or timestamp == "":
        return JsonResponse({"error": "Empty comment parameters."}, status=400)
    try:
        video = Post.objects.get(id=data.get("videoID"))
    except ObjectDoesNotExist:
        return JsonResponse({"error": "Invalid video."}, status=400)
    newComment = PostComment(
        user=request.user,
        text=text,
        timeStamp=timestamp,
        displayStamp=displaystamp,
        video = video
    )
    newComment.save()
    return JsonResponse({"message": "Comment successfully posted."}, status=200)

@csrf_exempt
@login_required
def reply(request):
    if request.method != "POST":
        return JsonResponse({"error": "POST method required."}, status=400)
    data = json.loads(request.body)
    text = data.get("text")
    if text == "":
        return JsonResponse({"error": "Empty comment text."}, status=400)
    try:
        video = Post.objects.get(id=data.get("videoID"))
    except ObjectDoesNotExist:
        return JsonResponse({"error": "Invalid video."}, status=400)
    try:
        comment = PostComment.objects.get(id=data.get("commentID"))
    except ObjectDoesNotExist:
        return JsonResponse({"error": "Invalid reply target"}, status=400)
    newReply = PostCommentReply(
        user = request.user,
        text = text
    )
    newReply.save()
    comment.replies.add(newReply)
    comment.save()
    return JsonResponse({"message": "Reply posted successfully."}, status=200)